from confluent_kafka import Producer
import requests
import json
import time

# Kafka producer configuration
bootstrap_servers = 'localhost:9092'
topic = 'pred'
producer_conf = {'bootstrap.servers': bootstrap_servers}

# Create Kafka producer
producer = Producer(producer_conf)
# URL to fetch data from
url = 'http://127.0.0.1:5000/generate_fake_data'

# Function to fetch data from URL and publish to Kafka topic
def fetch_and_publish():
    while True:
        try:
            # Fetch data from URL
            response = requests.get(url)
            if response.status_code == 200:
                # Parse JSON response
                data = response.json()
                # Convert data to JSON string
                message_value = json.dumps(data)
                # Publish message to Kafka topic
                producer.produce(topic, value=message_value)
                # Flush producer to ensure message delivery
                producer.flush()
                print("Message published to Kafka topic:", topic)
            else:
                print("Failed to fetch data from URL. Status code:", response.status_code)
        except Exception as e:
            print("Error:", e)
        # Sleep for some time before fetching data again
        time.sleep(5)

# Call the fetch_and_publish function
fetch_and_publish()
