import streamlit as st
import pandas as pd
import time
import altair as alt
from itertools import count
from datetime import datetime

# Load the predictions.csv file
df = pd.read_csv('predictions.csv')


# Function to simulate real-time updates
def generate_data():
    for index, row in df.iterrows():
        yield row




# Create a Streamlit app
st.title('Network Congestion Management')

st.sidebar.title("INCOMING DATA")
st.write("TRAFFIC INCOMING")

# Add a placeholder for the data
data_placeholder = st.sidebar.empty()

feature_placeholder = st.empty()
st.write("\nTRAFFIC TIMELINE")
# Initialize data for the line chart
chart_data = pd.DataFrame(columns=['time', 'duration'])

# Initialize a placeholder for the line chart
chart_placeholder = st.empty()
st.write("BANDWIDTH MANAGEMENT CONSOLE")
bandwidth_placeholder=st.empty()
no_placeholder=st.empty()
data_counter=0
latest_records = []
no_congestion=[]
# Iterate over the data and update the placeholder
for data in generate_data():
    data_placeholder.json(data.to_dict())
    sourcebytes = data.get('srcbytes')
    protocoltype = data.get('protocoltype')
    bandwidth=data.get('bandwidth.2f')
    destibytes = data.get('dstbytes')
    duration = data.get('duration') 
    protocol=data.get('protocoltype')
    if data['class'] ==0:
         latest_records.append(f"\nNo Congestion occurred with {sourcebytes} Mbps\n and protocol {protocol} with bandwidth {bandwidth}")
    if len(latest_records) > 5:
            latest_records.pop(0)

    if data['class'] == 1:
        if data['protocoltype'] == 'tcp':
            latest_records.append(f"\nCongestion occurred with {sourcebytes} Mbps\n and protocol {protocol} with bandwidth {bandwidth} set to Normal")
        
        
        # Update the line chart data
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        new_data = pd.DataFrame({'time': [current_time], 'duration': [duration]})
        chart_data = pd.concat([chart_data, new_data])


        ## Render the line chart in Streamlit with the latest 20 data points
        chart_placeholder.line_chart(chart_data.set_index('time').tail(20))
    
        # Update other placeholders
        feature_placeholder.markdown(f"```yaml\nDuration of traffic: {duration:.2f} seconds\ndata bytes from source: {sourcebytes:.2f} bytes\ndata bytes to destination: {destibytes:.2f} bytes\nProtocol Type:{protocoltype:}", unsafe_allow_html=True)
        

        bandwidth = data.get('bandwidth')
        
        
            
          # Keep only the latest 10 records

    # Update the bandwidth_placeholder
        bandwidth_placeholder.markdown("\n".join(reversed(latest_records)), unsafe_allow_html=True)
        # Increment the data counter
        data_counter += 1
    
    time.sleep(1)  # Simulate real-time updates
