from flask import Flask, jsonify
import random

app = Flask(__name__)

# Define the order of attributes
ordered_keys = [
    "duration", "protocoltype", "service", "flag", "srcbytes", "dstbytes",
    "land", "wrongfragment", "urgent", "hot", "numfailedlogins", "loggedin",
    "numcompromised", "rootshell", "suattempted", "numroot", "numfilecreations",
    "numshells", "numaccessfiles", "numoutboundcmds", "ishostlogin",
    "isguestlogin", "count", "srvcount", "serrorrate", "srvserrorrate",
    "rerrorrate", "srvrerrorrate", "samesrvrate", "diffsrvrate",
    "srvdiffhostrate", "dsthostcount", "dsthostsrvcount",
    "dsthostsamesrvrate", "dsthostdiffsrvrate", "dsthostsamesrcportrate",
    "dsthostsrvdiffhostrate", "dsthostserrorrate", "dsthostsrvserrorrate",
    "dsthostrerrorrate", "dsthostsrvrerrorrate"
]

# Define unique values for 'service', 'protocoltype', and 'flag'
unique_values = {
    "service": ['http', 'private', 'remote_job', 'ftp_data', 'name', 'netbios_ns', 'eco_i', 'mtp', 'other',
                'telnet', 'finger', 'domain_u', 'supdup', 'uucp_path', 'Z39_50', 'smtp', 'csnet_ns', 'uucp',
                'netbios_dgm', 'urp_i', 'auth', 'domain', 'ftp', 'bgp', 'ldap', 'ecr_i', 'gopher', 'vmnet',
                'systat', 'http_443', 'efs', 'whois', 'imap4', 'iso_tsap', 'echo', 'klogin', 'link', 'sunrpc',
                'login', 'kshell', 'sql_net', 'time', 'hostnames', 'exec', 'ntp_u', 'discard', 'nntp', 'courier',
                'ctf', 'ssh', 'daytime', 'shell', 'netstat', 'pop_3', 'nnsp', 'IRC', 'pop_2', 'printer', 'tim_i',
                'pm_dump', 'red_i', 'netbios_ssn', 'rje', 'X11', 'urh_i', 'http_8001'],
    "protocoltype": ['icmp', 'tcp', 'udp'],
    "flag": ['SF', 'REJ', 'S0', 'RSTR', 'SH', 'RSTO', 'S1', 'RSTOS0', 'S3', 'S2', 'OTH']
}


# Define the route to generate fake data
@app.route('/generate_fake_data', methods=['GET'])
def generate_fake_data():
    fake_row = {
        "duration": random.randint(0, 42862),
        "protocoltype": random.choice(unique_values["protocoltype"]),
        "service": random.choice(unique_values["service"]),
        "flag": random.choice(unique_values["flag"]),
        "srcbytes": random.randint(0, 10000),
        "dstbytes": random.randint(0, 10000),
        "land": random.choice([0, 1]),
        "wrongfragment": random.randint(0, 3),
        "urgent": random.randint(0, 1),
        "hot": random.randint(0, 100),
        "numfailedlogins": random.randint(0, 4),
        "loggedin": random.choice([0, 1]),
        "numcompromised": random.randint(0, 884),
        "rootshell": random.choice([0, 1]),
        "suattempted": random.randint(0, 2),
        "numroot": random.randint(0, 975),
        "numfilecreations": random.randint(0, 40),
        "numshells": random.randint(0, 1),
        "numaccessfiles": random.randint(0, 8),
        "numoutboundcmds": random.randint(0,0),
        "ishostlogin": random.randint(0,0),
        "isguestlogin": random.choice([0, 1]),
        "count": random.randint(0, 510),
        "srvcount": random.randint(0, 510),
        "serrorrate": round(random.uniform(0, 1), 2),
        "srvserrorrate": round(random.uniform(0, 1), 2),
        "rerrorrate": round(random.uniform(0, 1), 2),
        "srvrerrorrate": round(random.uniform(0, 1), 2),
        "samesrvrate": round(random.uniform(0, 1), 2),
        "diffsrvrate": round(random.uniform(0, 1), 2),
        "srvdiffhostrate": round(random.uniform(0, 1), 2),
        "dsthostcount": random.randint(0, 255),
        "dsthostsrvcount": random.randint(0, 255),
        "dsthostsamesrvrate": random.randint(0,255),
        "dsthostdiffsrvrate": round(random.uniform(0, 1), 2),
        "dsthostsamesrcportrate": round(random.uniform(0, 1), 2),
        "dsthostsrvdiffhostrate": round(random.uniform(0, 1), 2),
        "dsthostserrorrate": round(random.uniform(0, 1), 2),
        "dsthostsrvserrorrate": round(random.uniform(0, 1), 2),
        "dsthostrerrorrate": round(random.uniform(0, 1), 2),
        "dsthostsrvrerrorrate": round(random.uniform(0, 1), 2),
        
    }

    return jsonify(fake_row)

if __name__ == '__main__':
    app.run(debug=True)
