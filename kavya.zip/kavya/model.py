import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib

# Load the dataset
df = pd.read_csv('congest.csv')

# Preprocess the data
cc = df.select_dtypes(include=['object']).columns
label_encoder = LabelEncoder()
for column in cc:
    df[column] = label_encoder.fit_transform(df[column])


# Splitting the dataset into training and testing sets
X = df[['duration', 'protocoltype', 'service', 'flag', 'srcbytes',  'numoutboundcmds', 'count', 'srvcount', 'serrorrate', 'srvserrorrate', 'rerrorrate', 'srvrerrorrate', 'samesrvrate', 'diffsrvrate', 'srvdiffhostrate', 'dsthostcount', 'dsthostsrvcount', 'dsthostsamesrvrate', 'dsthostdiffsrvrate', 'dsthostsamesrcportrate', 'dsthostsrvdiffhostrate', 'dsthostsrvrerrorrate', 'dsthostsrvserrorrate', 'dsthostrerrorrate', 'dsthostserrorrate', 'dsthostrerrorrate', 'dsthostsrvserrorrate', 'dsthostrerrorrate', 'dsthostsrvrerrorrate']]
y = df['class']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Training the model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Save the trained model to a pickle file
joblib.dump(model, 'model.pkl')
