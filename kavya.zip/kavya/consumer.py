import csv
from confluent_kafka import Consumer, KafkaError
import json
import pandas as pd
from sklearn.preprocessing import LabelEncoder
import joblib
import matplotlib.pyplot as plt

# Load the trained ML model
model = joblib.load('model.pkl')

# Configure Kafka consumer
conf = {'bootstrap.servers': "localhost:9092",
        'group.id': "ml_group",
        'auto.offset.reset': 'earliest'}

consumer = Consumer(conf)
topic = 'pred'
consumer.subscribe([topic])
label_encoder_protocoltype = LabelEncoder()
label_encoder_service = LabelEncoder()
label_encoder_flag = LabelEncoder()

# Open predictions.csv file in write mode
with open('predictions.csv', 'w', newline='') as csvfile:
    fieldnames = ['duration', 'protocoltype', 'service', 'flag', 'srcbytes', 'dstbytes', 'land', 'wrongfragment', 'urgent', 'hot', 'numfailedlogins', 'loggedin', 'numcompromised', 'rootshell', 'suattempted', 'numroot', 'numfilecreations', 'numshells', 'numaccessfiles', 'numoutboundcmds', 'ishostlogin', 'isguestlogin', 'count', 'srvcount', 'serrorrate', 'srvserrorrate', 'rerrorrate', 'srvrerrorrate', 'samesrvrate', 'diffsrvrate', 'srvdiffhostrate', 'dsthostcount', 'dsthostsrvcount', 'dsthostsamesrvrate', 'dsthostdiffsrvrate', 'dsthostsamesrcportrate', 'dsthostsrvdiffhostrate', 'dsthostsrvrerrorrate', 'dsthostsrvserrorrate', 'dsthostrerrorrate', 'dsthostserrorrate', 'dsthostrerrorrate', 'dsthostsrvserrorrate', 'dsthostrerrorrate', 'dsthostsrvrerrorrate', 'class','bandwidth']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()

    # Number of data points to consume
    num_data_points = 1000  # Change this to the desired number

    # Counter for the number of consumed data points
    count = 0
    

    # Main loop to consume messages from Kafka topic
    while count < num_data_points:
        try:
            msg = consumer.poll(timeout=1.0)
            if msg is None:
                continue
            if msg.error():
                if msg.error().code() == KafkaError._PARTITION_EOF:
                    continue
                else:
                    print(msg.error())
                    break
            data = json.loads(msg.value().decode('utf-8'))
            print("Received data:")
            print(data)

            # Rearrange the data according to the expected order
            rearranged_data = {
                'duration': data['duration'],
                
                'protocoltype': label_encoder_protocoltype.fit_transform([data['protocoltype']])[0],
                'service': label_encoder_service.fit_transform([data['service']])[0],
                'flag': label_encoder_flag.fit_transform([data['flag']])[0],
                'srcbytes': data['srcbytes'],
                'dstbytes': data['dstbytes'],
                'land': data['land'],
                'wrongfragment': data['wrongfragment'],
                'urgent': data['urgent'],
                'hot': data['hot'],
                'numfailedlogins': data['numfailedlogins'],
                'loggedin': data['loggedin'],
                'numcompromised': data['numcompromised'],
                'rootshell': data['rootshell'],
                'suattempted': data['suattempted'],
                'numroot': data['numroot'],
                'numfilecreations': data['numfilecreations'],
                'numshells': data['numshells'],
                'numaccessfiles': data['numaccessfiles'],
                'numoutboundcmds': data['numoutboundcmds'],
                'ishostlogin': data['ishostlogin'],
                'isguestlogin': data['isguestlogin'],
                'count': data['count'],
                'srvcount': data['srvcount'],
                'serrorrate': data['serrorrate'],
                'srvserrorrate': data['srvserrorrate'],
                'rerrorrate': data['rerrorrate'],
                'srvrerrorrate': data['srvrerrorrate'],
                'samesrvrate': data['samesrvrate'],
                'diffsrvrate': data['diffsrvrate'],
                'srvdiffhostrate': data['srvdiffhostrate'],
                'dsthostcount': data['dsthostcount'],
                'dsthostsrvcount': data['dsthostsrvcount'],
                'dsthostsamesrvrate': data['dsthostsamesrvrate'],
                'dsthostdiffsrvrate': data['dsthostdiffsrvrate'],
                'dsthostsamesrcportrate': data['dsthostsamesrcportrate'],
                'dsthostsrvdiffhostrate': data['dsthostsrvdiffhostrate'],
                'dsthostsrvrerrorrate': data['dsthostsrvrerrorrate'],
                'dsthostsrvserrorrate': data['dsthostsrvserrorrate'],
                'dsthostrerrorrate': data['dsthostrerrorrate'],
                'dsthostserrorrate': data['dsthostserrorrate'],
                'dsthostrerrorrate': data['dsthostrerrorrate'],
                'dsthostsrvserrorrate': data['dsthostsrvserrorrate'],
                'dsthostrerrorrate': data['dsthostrerrorrate'],
                'dsthostsrvrerrorrate': data['dsthostsrvrerrorrate']
            }   

            

            # Convert the rearranged data to a DataFrame
            df = pd.DataFrame([rearranged_data])
            X_pred = df[['duration', 'protocoltype', 'service', 'flag', 'srcbytes',  'numoutboundcmds', 'count', 'srvcount', 'serrorrate', 'srvserrorrate', 'rerrorrate', 'srvrerrorrate', 'samesrvrate', 'diffsrvrate', 'srvdiffhostrate', 'dsthostcount', 'dsthostsrvcount', 'dsthostsamesrvrate', 'dsthostdiffsrvrate', 'dsthostsamesrcportrate', 'dsthostsrvdiffhostrate', 'dsthostsrvrerrorrate', 'dsthostsrvserrorrate', 'dsthostrerrorrate', 'dsthostserrorrate', 'dsthostrerrorrate', 'dsthostsrvserrorrate', 'dsthostrerrorrate', 'dsthostsrvrerrorrate']]

# Make predictions using the loaded model
            prediction = model.predict(X_pred)

            

            # Inverse transform 'protocoltype', 'service', and 'flag' back to text
            rearranged_data['protocoltype'] = label_encoder_protocoltype.inverse_transform([rearranged_data['protocoltype']])[0]
            rearranged_data['service'] = label_encoder_service.inverse_transform([rearranged_data['service']])[0]
            rearranged_data['flag'] = label_encoder_flag.inverse_transform([rearranged_data['flag']])[0]
            df['bandwidth'] = df['srcbytes'] / df['duration'].replace(0, 1)

            # Add 'class' column to rearranged_data
            rearranged_data['class'] = prediction[0]
            rearranged_data['bandwidth'] = df['bandwidth'].iloc[0]
            # Write the rearranged data to detect.csv
            writer.writerow(rearranged_data)

            # Increment the counter
            count += 1

        

        except Exception as e:
            print("Error:", e)

# Close Kafka consumer
consumer.close()
